#include "Resource.h"

Resource::Resource(std::string dataPath) {
	this->_dataPath = dataPath;
}

void Resource::fileName(std::string name) {

}